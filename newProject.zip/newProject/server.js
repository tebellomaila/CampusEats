
  
const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
  // console.log(req);
  console.log(req.url);

  // set header content type
  res.setHeader('Content-Type', 'text/html');


  // send html file
  /*fs.readFile('./views/index.html', (err, data) => {
    if (err) {
     console.log(err);
      res.end();
  }else{
  res.write(data);
    res.end();}
  });/*/

  // routing
  let path = './views/';
  switch(req.url) {
    case '/':
      path += 'index.html';
      res.statusCode = 200;
      break;
    case '/login':
      path += 'login.html';
      res.statusCode = 200;
      break;
	  case '/menu':
      path += 'menu.html';
      res.statusCode = 200;
      break;
	    case '/register':
      path += 'register.html';
      res.statusCode = 200;
      break;
   
  }

  // send html
  fs.readFile(path, (err, data) => {
    if (err) {
      console.log(err);
      res.end();
    }
    //res.write(data);
    res.end(data);
  });


});

// localhost is the default value for 2nd argument
server.listen(3000, 'localhost', () => {
  console.log('Waiting for requests on port 3000');
});

